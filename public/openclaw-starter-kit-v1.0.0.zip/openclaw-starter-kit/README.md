# OpenClaw Starter Kit v1.0.0
## Thank you for your purchase!

This kit gives you 10 essential OpenClaw skills, pre-configured and
ready to install. Follow the steps below and you'll be up and running
in under 5 minutes.

---

## Installation

1. Open your terminal
2. Run the install script:

   bash install.sh

   This installs all 10 skills via the clawhub CLI automatically.

3. Restart your OpenClaw agent
4. Test with: "Hey, what's the weather today?"

---

## What's included

| # | Skill          | What it does                        |
|---|----------------|-------------------------------------|
| 1 | weather        | Current weather & forecasts         |
| 2 | wacli          | WhatsApp send & receive             |
| 3 | gog            | Gmail, Calendar, Drive              |
| 4 | xurl           | Twitter/X search & post             |
| 5 | github         | GitHub issues, PRs, CI status       |
| 6 | blogwatcher    | RSS feed monitoring & digests       |
| 7 | himalaya       | IMAP/SMTP email management          |
| 8 | sonoscli       | Sonos speaker control               |
| 9 | obsidian       | Obsidian vault notes                |
|10 | gifgrep        | GIF search & download               |

---

## Quick-start prompts

Once installed, try these with your agent:

- "What's the weather in Brussels this weekend?"
- "Send a WhatsApp to [contact] saying I'm on my way"
- "What's on my Google Calendar tomorrow?"
- "Search GitHub for open issues in my repo"
- "Show me the latest posts from my RSS feeds"
- "Play some music on Sonos in the living room"
- "Create a new note in Obsidian called Meeting Notes"
- "Check my email for unread messages"

---

## Need help?

- Docs: https://docs.openclaw.ai
- Skills: https://clawhub.ai
- Site: https://clawmatic.eu

