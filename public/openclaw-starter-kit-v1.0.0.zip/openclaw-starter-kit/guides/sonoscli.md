# Sonos Speaker Control

**Skill:** `sonoscli`
**Clawhub:** https://clawhub.ai/skills/sonoscli

## Setup

After running install.sh, this skill is ready to use.
Some skills require API keys or account auth — run:

```
clawhub info sonoscli
```

...to see what's needed for your specific setup.

## Example prompts

- "Play some jazz in the living room"
- "Turn up the volume in the kitchen"
- "Pause all Sonos speakers"

## Docs

Full documentation: https://docs.openclaw.ai
