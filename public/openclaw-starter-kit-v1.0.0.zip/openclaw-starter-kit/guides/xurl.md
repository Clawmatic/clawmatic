# Twitter/X

**Skill:** `xurl`
**Clawhub:** https://clawhub.ai/skills/xurl

## Setup

After running install.sh, this skill is ready to use.
Some skills require API keys or account auth — run:

```
clawhub info xurl
```

...to see what's needed for your specific setup.

## Example prompts

- "Search Twitter for OpenClaw mentions"
- "Post a tweet: Just set up my OpenClaw agent! 🤖"
- "Show me trending topics in Belgium"

## Docs

Full documentation: https://docs.openclaw.ai
