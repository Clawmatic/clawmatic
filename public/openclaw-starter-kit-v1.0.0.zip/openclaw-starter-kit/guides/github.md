# GitHub

**Skill:** `github`
**Clawhub:** https://clawhub.ai/skills/github

## Setup

After running install.sh, this skill is ready to use.
Some skills require API keys or account auth — run:

```
clawhub info github
```

...to see what's needed for your specific setup.

## Example prompts

- "List open issues in my repo"
- "What PRs are waiting for my review?"
- "Check the CI status on my latest commit"

## Docs

Full documentation: https://docs.openclaw.ai
