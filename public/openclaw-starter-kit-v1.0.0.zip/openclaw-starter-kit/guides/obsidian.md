# Obsidian Notes

**Skill:** `obsidian`
**Clawhub:** https://clawhub.ai/skills/obsidian

## Setup

After running install.sh, this skill is ready to use.
Some skills require API keys or account auth — run:

```
clawhub info obsidian
```

...to see what's needed for your specific setup.

## Example prompts

- "Create a new note called Meeting Notes"
- "Search my vault for notes about the project"
- "What did I write about last week?"

## Docs

Full documentation: https://docs.openclaw.ai
