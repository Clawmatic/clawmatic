# Email (IMAP/SMTP)

**Skill:** `himalaya`
**Clawhub:** https://clawhub.ai/skills/himalaya

## Setup

After running install.sh, this skill is ready to use.
Some skills require API keys or account auth — run:

```
clawhub info himalaya
```

...to see what's needed for your specific setup.

## Example prompts

- "Check my unread emails"
- "Reply to the last email from Sarah"
- "Move all emails from newsletter@x.com to trash"

## Docs

Full documentation: https://docs.openclaw.ai
