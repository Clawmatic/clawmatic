# GIF Search

**Skill:** `gifgrep`
**Clawhub:** https://clawhub.ai/skills/gifgrep

## Setup

After running install.sh, this skill is ready to use.
Some skills require API keys or account auth — run:

```
clawhub info gifgrep
```

...to see what's needed for your specific setup.

## Example prompts

- "Find a funny reaction GIF for when things go wrong"
- "Search for a celebration GIF"
- "Download the top result for 'mind blown'"

## Docs

Full documentation: https://docs.openclaw.ai
