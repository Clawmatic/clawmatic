# RSS & Blog Feeds

**Skill:** `blogwatcher`
**Clawhub:** https://clawhub.ai/skills/blogwatcher

## Setup

After running install.sh, this skill is ready to use.
Some skills require API keys or account auth — run:

```
clawhub info blogwatcher
```

...to see what's needed for your specific setup.

## Example prompts

- "What are the latest posts from my feeds?"
- "Summarize today's tech news from my RSS list"
- "Add Hacker News to my feed list"

## Docs

Full documentation: https://docs.openclaw.ai
