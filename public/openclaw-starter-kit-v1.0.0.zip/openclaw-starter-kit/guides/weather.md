# Weather Lookups

**Skill:** `weather`
**Clawhub:** https://clawhub.ai/skills/weather

## Setup

After running install.sh, this skill is ready to use.
Some skills require API keys or account auth — run:

```
clawhub info weather
```

...to see what's needed for your specific setup.

## Example prompts

- "What's the weather in Brussels?"
- "Will it rain this weekend in Ghent?"
- "What's the forecast for the next 5 days?"

## Docs

Full documentation: https://docs.openclaw.ai
