# Google Workspace (Gmail + Calendar + Drive)

**Skill:** `gog`
**Clawhub:** https://clawhub.ai/skills/gog

## Setup

After running install.sh, this skill is ready to use.
Some skills require API keys or account auth — run:

```
clawhub info gog
```

...to see what's needed for your specific setup.

## Example prompts

- "What's on my calendar tomorrow?"
- "Draft an email to my boss about the project update"
- "Find files in my Drive about the Q1 report"

## Docs

Full documentation: https://docs.openclaw.ai
