# WhatsApp Messaging

**Skill:** `wacli`
**Clawhub:** https://clawhub.ai/skills/wacli

## Setup

After running install.sh, this skill is ready to use.
Some skills require API keys or account auth — run:

```
clawhub info wacli
```

...to see what's needed for your specific setup.

## Example prompts

- "Send a WhatsApp to John: I'll be 10 minutes late"
- "Show my last 5 WhatsApp messages"
- "Summarize my WhatsApp chats from today"

## Docs

Full documentation: https://docs.openclaw.ai
