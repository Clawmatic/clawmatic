#!/usr/bin/env bash
# OpenClaw Starter Kit - Installer
# Installs 10 essential skills via clawhub CLI
# https://clawmatic.eu

set -e

GREEN='\033[0;32m'
PURPLE='\033[0;35m'
DIM='\033[2m'
NC='\033[0m'

echo ""
echo -e "${GREEN}╔══════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   OpenClaw Starter Kit — Installer   ║${NC}"
echo -e "${GREEN}║         clawmatic.eu  v1.0.0         ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════╝${NC}"
echo ""

# Check clawhub CLI
if ! command -v clawhub &> /dev/null; then
  echo "❌ clawhub CLI not found."
  echo "   Install it first: npm install -g clawhub"
  echo "   Then re-run this script."
  exit 1
fi

SKILLS=(
  "weather"
  "wacli"
  "gog"
  "xurl"
  "github"
  "blogwatcher"
  "himalaya"
  "sonoscli"
  "obsidian"
  "gifgrep"
)

TOTAL=${#SKILLS[@]}
COUNT=0

echo -e "${DIM}Installing $TOTAL skills...${NC}"
echo ""

for skill in "${SKILLS[@]}"; do
  COUNT=$((COUNT + 1))
  echo -e "${PURPLE}[$COUNT/$TOTAL]${NC} Installing ${GREEN}$skill${NC}..."
  clawhub install "$skill" --yes 2>/dev/null && \
    echo -e "        ${GREEN}✓ $skill installed${NC}" || \
    echo -e "        ⚠️  $skill skipped (already installed or not available)"
done

echo ""
echo -e "${GREEN}✅ Done! $TOTAL skills installed.${NC}"
echo ""
echo "Next steps:"
echo "  1. Restart your OpenClaw agent"
echo "  2. Check guides/ folder for setup tips per skill"
echo "  3. Try: \"Hey, what's the weather today?\""
echo ""
echo -e "${DIM}Need help? https://clawmatic.eu${NC}"
echo ""
